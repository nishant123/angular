# EmployeeWebAPIApplication

  > Restore nuget packages needed for solution
  
  > Run the solution

## AngularCRUDApplication

  > Run `npm install`
  
  > Replace the above `apiUrl` inside `src/app/Service/http-provider.service.ts`. Example : http://localhost:8100/
  
  > Run `ng serve` for a dev server

## Blog reference
[How to Build a CRUD App in Angular](https://www.syncfusion.com/blogs/post/how-to-build-a-crud-app-in-angular.aspx)
